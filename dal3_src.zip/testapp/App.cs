using System;
using DAL;

namespace TestApp
{

	public class App
	{
	
		public static void Main()
		{
			
			DAL dal = new DAL();
			
			try
			{
				
				Contact contact = new Contact();
				contact.Name = "Joao Cardoso";
				contact.Age  = 23;
				contact.Address = "Av. Rio Branco, 202/121";
				contact.Address2 = "Centro";
				contact.PostalCode = "09029-901";
				contact.City = "Sao Paulo";
				contact.State =  "SP";
				contact.Country = "Brazil";
				
				dal.UpdateObject(contact);				
				Console.WriteLine(contact);
				
				
				Contact joaoCardoso = (Contact)dal.RetrieveObject(1, typeof(Contact));
				joaoCardoso.Age++;
				Console.WriteLine(joaoCardoso);					
				Console.WriteLine("");
				
				
				Customer customer = new Customer();
				customer.Name = "Paul Noyter";
				customer.Age  = 34;
				customer.Address = "All St, 2202/2121";
				customer.Address2 = "Downville";
				customer.PostalCode = "90931";
				customer.City = "Los Angeles";
				customer.State =  "CA";
				customer.Country = "United States";
				customer.TotalPurchased += 1900.87M;
				customer.NumberOfPurchases++;
				
				dal.UpdateObject(customer);
				
				
				Customer paul = (Customer)dal.RetrieveObject(1, typeof(Customer));
				Console.WriteLine(paul);
				
				paul.TotalPurchased += 100M;
				paul.NumberOfPurchases++;
				dal.UpdateObject(paul);
				
				if (paul.Dependents.Count == 0)
				{
					CustomerDependent dependent = paul.NewDependent();
					dependent.Name = "Marie Noyter";
					dependent.Age = 31;
					paul.Dependents.Add(dependent);
				
				
					dependent = paul.NewDependent();
					dependent.Name = "Mark Noyter";
					dependent.Age = 10;
					paul.Dependents.Add(dependent);
					
					
					dependent = paul.NewDependent();
					dependent.Name = "Claudia Snorg";
					dependent.Age = 32;
					dependent.Relationship = CustomerRelationship.Friend;					
					paul.Dependents.Add(dependent);
				
					dal.UpdateCustomerDependents(paul);
				}
				else
				{
					Console.WriteLine("Dependents of {0}", paul.Name);
					
					foreach(CustomerDependent dependent in paul.Dependents)
					{
						Console.WriteLine("<Dependent>{0} - {1} [{2}]", dependent.Id, dependent.Name, dependent.Relationship);
						dependent.Relationship = CustomerRelationship.Family;
					}
					
					dal.UpdateCustomerDependents(paul);
				}
				
			}
			finally
			{
				dal.Dispose();
			}
		}
	}
	
}