using System;
using System.Collections;
using System.Data;
using DAL;


namespace TestApp
{
	public class Person
	{
		string name = "";
		int age = 0;
		int id = 0;
		
		
		[KeyField("id")]
		public int Id
		{
			get { return id;  }
			set { id = value; }
		}
		
		[DataField("name", Size=50)]
		public string Name
		{
			get { return name;  }
			set { name = value; }
		}
		
		[DataField("age")]
		public int Age
		{
			get { return age;  }
			set { age = value; }
		}
		
		public override string ToString()
		{
			return string.Format("<Person>{0}, {1} years old", Name, Age);
		}
	}


	[DataTable("contact", UpdateStoredProcedure="sp_UpdateContact")]
	public class Contact : Person
	{
		string phone = "";
		string email = "";
		string address = "";
		string address2 = "";
		string city = "";
		string postalCode = "";
		string state = "";
		string country = "";
		
		[DataField("phone", Size=20)]
		public string Phone
		{
			get { return phone;  }
			set { phone = value; }
		}
		
		[DataField("email", Size=80)]
		public string Email
		{
			get { return email;  }
			set { email = value; }
		}
		
		[DataField("address", Size=80)]
		public string Address
		{
			get { return address;  }
			set { address = value; }
		}		
	
	
		[DataField("address2", Size=80)]
		public string Address2
		{
			get { return address2;  }
			set { address2 = value; }
		}	
		
		
		[DataField("city", Size=50)]
		public string City
		{
			get { return city;  }
			set { city = value; }
		}		
		
		
		[DataField("postalCode", Size=20)]
		public string PostalCode
		{
			get { return postalCode;  }
			set { postalCode = value; }
		}		
		
		
		[DataField("state", Size=4)]
		public string State
		{
			get { return state;  }
			set { state = value; }
		}		
		
		
		[DataField("country", Size=50)]
		public string Country
		{
			get { return country;  }
			set { country = value; }
		}		
		
		
		public override string ToString()
		{
			return string.Format("<Contact>{0} - {1} from {2}", Id, Name, Country);
		}
	}


	public enum CustomerRelationship { Family, Friend, Other };

	[DataTable("customerDependent", UpdateStoredProcedure="sp_UpdateCustomerDependent")]
	public class CustomerDependent : Person
	{
		int customerId = 0;
		CustomerRelationship relationship = CustomerRelationship.Family;
		
		protected CustomerDependent()
		{
		
		}
		
		public CustomerDependent(int customerId)
		{
			this.customerId = customerId;
		}
		
		[ForeignKeyFieldAttribute("customerId")]
		public int CustomerId
		{
			get { return customerId;  }
			set { customerId = value; }
		}
		
		[DataFieldAttribute("relationship")]
		public CustomerRelationship Relationship
		{
			get { return relationship;  }
			set { relationship = value; }
		}				
	}

	
	
	
	public enum CustomerStatus { Active, Inactive };
	
	[DataTable("customer", UpdateStoredProcedure="sp_UpdateCustomer")]
	public class BaseCustomer : Contact
	{
		CustomerStatus status = CustomerStatus.Active;
		Decimal totalPurchased = 0M;
		int numberOfPurchases  = 0;
		DateTime dateRegistered = DateTime.Now;		
		
		[DataField("status")]
		public CustomerStatus Status
		{
			get { return status;  }
			set { status = value; }
		}
		
		
		[DataField("totalPurchased")]
		public Decimal TotalPurchased
		{
			get { return totalPurchased;  }
			set { totalPurchased = value; }
		}
		
		[DataField("numberOfPurchases")]
		public int NumberOfPurchases
		{
			get { return numberOfPurchases;  }
			set { numberOfPurchases = value; }
		}
		
		[DataField("dateRegistered")]
		public DateTime DateRegistered
		{
			get { return dateRegistered;  }
			set { dateRegistered = value; }
		}
	
		
		public override string ToString()
		{
			return string.Format("<Customer>{0} - {1} from {2}, registered in {3}. #{4} purchases spending a total of $ {5}",
					  	Id,
					  	Name, 
					  	Country,
					  	DateRegistered,
					  	NumberOfPurchases,
					  	TotalPurchased);
		}
	
	}
	
	public class Customer : BaseCustomer
	{
		
		ArrayList dependents = null;
		
		public ArrayList Dependents
		{
			get
			{
				if (dependents == null)
				{
					DAL dal = new DAL();
					dependents = dal.GetCustomerDependents(this);
				}
				
				return dependents;
			}
		}
		
		public CustomerDependent NewDependent()
		{
			return new CustomerDependent(Id);
		}
	
		public Decimal PurchaseMedia
		{
			get { return TotalPurchased / NumberOfPurchases; }
		}
	
	
	}
		
}