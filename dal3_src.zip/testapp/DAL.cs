using System;
using System.Collections;
using DAL;


namespace TestApp
{


	public class DAL : DALSqlEngine
	{
		const string CONN_STRING = "server=localhost;uid=sa;pwd=;database=pubs";
		
		public DAL() : base(CONN_STRING)
		{
		
		}
		
		public ArrayList GetCustomerDependents(Customer customer)
		{
			ArrayList result = new ArrayList();
			
			RetrieveChildObjects(customer.Id, result, typeof(CustomerDependent));
			
			return result;
		}
		
		public void UpdateCustomerDependents(Customer customer)
		{
			UpdateObjects(customer.Dependents);
		}
	}
}