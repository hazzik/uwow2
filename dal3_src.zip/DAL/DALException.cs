using System;
using System.Data;



namespace DAL
{

	public class DALException : Exception
	{

		public DALException(string message, Exception innerException) : base(message, innerException)
		{
			
		
		}





	}


}