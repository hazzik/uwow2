if exists (select * from sysobjects where id = object_id(N'[dbo].[contact]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[contact]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[customer]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[customer]
GO

if exists (select * from sysobjects where id = object_id(N'[dbo].[customerDependent]') and OBJECTPROPERTY(id, N'IsUserTable') = 1)
drop table [dbo].[customerDependent]
GO

CREATE TABLE [dbo].[contact] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[name] [varchar] (50) NOT NULL ,
	[age] [int] NOT NULL ,
	[address] [varchar] (80) NOT NULL ,
	[postalCode] [varchar] (20) NOT NULL ,
	[phone] [varchar] (20) NOT NULL ,
	[email] [varchar] (80) NOT NULL ,
	[address2] [varchar] (80) NOT NULL ,
	[city] [varchar] (50) NOT NULL ,
	[state] [varchar] (4) NOT NULL ,
	[country] [varchar] (50) NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[customer] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[name] [varchar] (50) NOT NULL ,
	[age] [int] NOT NULL ,
	[address] [varchar] (80) NOT NULL ,
	[postalCode] [varchar] (20) NOT NULL ,
	[phone] [varchar] (50) NOT NULL ,
	[email] [varchar] (80) NOT NULL ,
	[address2] [varchar] (80) NOT NULL ,
	[city] [varchar] (50) NOT NULL ,
	[state] [varchar] (4) NOT NULL ,
	[country] [varchar] (50) NOT NULL ,
	[totalPurchased] [money] NOT NULL ,
	[numberOfPurchases] [int] NOT NULL ,
	[dateRegistered] [datetime] NOT NULL ,
	[status] [smallint] NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[customerDependent] (
	[id] [int] IDENTITY (1, 1) NOT NULL ,
	[name] [varchar] (50) NOT NULL ,
	[customerId] [int] NOT NULL ,
	[relationship] [int] NOT NULL ,
	[age] [int] NOT NULL
) ON [PRIMARY]
GO
