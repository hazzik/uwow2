To build the DAL assembly and the test application run the buildall.bat.

Then execute the script defined in the file tables.sql using the SQL Server tool Query Analizer. Choose the pubs database. 
If you use a different database please change the connection string used in the test application.